/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utils;

import javax.swing.JOptionPane;

/**
 *
 * @author Mikael
 */
//public class ValidacaoUsuario {
    
//    private boolean ValidarFormularioCadastrarCliente() {
//        
//        if(this.txtNomeCliente.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um nome para o cliente!");
//            return false;
//        }
//        
//        if(this.txtCPFCliente.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um CPF para o cliente!");
//            return false;
//        }
//        
//        if(this.txtDataNascCliente.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina uma data de nascimento para o cliente!");
//            return false;
//        }
//        
//        if(this.txtCEP.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um CEP para o endereço do cliente!");
//            return false;
//        }
//        
//        if(this.txtRua.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina uma rua para o endereço do cliente!");
//            return false;
//        }
//        
//        if(this.txtNumero.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um numero para o endereço do cliente!");
//            return false;
//        }
//        
//        if(this.txtBairro.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um Bairro para o endereço do cliente!");
//            return false;
//        }
//        
//        if(this.txtCidade.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina uma cidade para o endereço do cliente!");
//            return false;
//        }
//        
//        if(this.txtCelular1.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um Celular para o cliente!");
//            return false;
//        }
//        
//        if(this.txtTelefone.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um Telefone para o cliente!");
//            return false;
//        }
//        
//        if(this.txtEmail.getText().equalsIgnoreCase(""))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um E-mail para o cliente!");
//            return false;
//        }
//                
//        int sexo = 0;
//        int estado = 0;
//        if(this.jcSexo1.equals(sexo))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um sexo para o cliente!");
//            return false;
//        }
//        if(this.jcEstado.equals(estado))
//        {
//            JOptionPane.showMessageDialog(this,"Defina um estado para o endereço do cliente!");
//            return false;
//        }
//        
//        return true;
//        
//    }
//}
